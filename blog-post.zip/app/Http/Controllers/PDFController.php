<?php

namespace App\Http\Controllers;

use PDF;
use App\Models\SuratMasuk;
use App\Models\SuratKeluar;
use Illuminate\Http\Request;

class PDFController extends Controller
{
    public function print_masuk(SuratMasuk $suratmasuk){
        
        $pdf = PDF::loadview('suratmasuk.suratmasukpdf',['suratmasuk'=>$suratmasuk]);
    	return $pdf->download('surat-masuk-pdf.pdf');
        
    }

    public function print_keluar(SuratKeluar $suratkeluar){
        
        $pdf = PDF::loadview('suratkeluar.suratkeluarpdf',['suratkeluar'=>$suratkeluar]);
        return $pdf->download('surat-keluar-pdf.pdf');
        
    }
}
