

<?php $__env->startSection('container'); ?>

<div class="mb-2">
  <a href="/surat-keluar" class="btn btn-danger btn-sm">Kembali</a>
  <div class="row">
    <div class="col-4 text-end">
      <img src="/img/Surat.png" alt="" style="width: 70%; align:right;">
    </div>
    <div class="col text-start">
      <h1 class="align-middle"><strong>Detail Surat Keluar</strong></h1>
      <p class="lead">Tolong perhatikan baik - baik setiap informasi pada surat dan pastikan surat sudah memiliki data yang benar</p>
      <a href="/surat-keluar/<?php echo e($suratkeluar->id); ?>/pdf" class="btn btn-primary">Print Surat</a>
      <a href="/surat-keluar/<?php echo e($suratkeluar->id); ?>/edit" class="btn btn-warning">Edit Surat</a>
      <form action="/surat-keluar/<?php echo e($suratkeluar->id); ?>" method="POST" class="d-inline">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
        <button class="btn btn-danger" type="submit" onclick="return confirm('Kamu yakin?')">
          Hapus
        </button>
      </form> 
    </div>
  </div>
</div>

<table class="table table-bordered table-striped table-hover">
    <thead>
      <tr>
        <th scope="col" colspan="4">Detail Surat keluar</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">Perihal</th>
        <td scope="col" colspan="3"><?php echo e($suratkeluar->perihal); ?></td>
      </tr>
      <tr>
        <th scope="row">No Urut</th>
        <td><?php echo e($suratkeluar->no_urut); ?></td>
        <th scope="row">Jumlah Lampiran</th>
        <td><?php echo e($suratkeluar->lampiran); ?> Lembar</td>
      </tr>
      <tr>
        <th scope="row">Kode</th>
        <td><?php echo e($suratkeluar->kode); ?></td>
        <th scope="row">Tanggal Surat</th>
        <td><?php echo e($suratkeluar->tanggal_surat); ?></td>
      </tr>
      <tr>
        <th scope="row">Pengolah</th>
        <td colspan="3"><?php echo e($suratkeluar->pengolah); ?></td>
      </tr>
      <tr>
        <th scope="row">Dari</th>
        <td scope="col" colspan="3"><?php echo e($suratkeluar->dari_kepada); ?></td>
      </tr>
      <tr>
        <th scope="row">Isi Ringkas</th>
        <td scope="col" colspan="3"><?php echo e($suratkeluar->isi_ringkas); ?></td>
      </tr>
      <tr>
        <th scope="row">Catatan</th>
        <td scope="col" colspan="3"><?php echo e($suratkeluar->catatan); ?></td>
      </tr>
    </tbody>
  </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NGODING ANJAY\Laravel\blog-post\resources\views/suratkeluar/show.blade.php ENDPATH**/ ?>