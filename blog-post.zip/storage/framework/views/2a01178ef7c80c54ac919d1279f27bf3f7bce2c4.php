

<?php $__env->startSection('container'); ?>

<?php if(session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
  <?php echo e(session('success')); ?>

  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>    
<?php endif; ?>

<div class="my-5">
    <h1 class="text-center"><strong>Cek Surat Masuk!</strong></h1>
    <p class="lead text-center">Cek semua surat masuk yang telah di input di halaman ini!</p>
</div>

<form action="/surat-masuk">
  <div class="row justify-content-md-center">
    <div class="col-5">
        <div class="input-group mb-4">
            <input type="text" class="form-control" placeholder="Cari Nomor Urut" name="search" value="<?php echo e(request('search')); ?>">
            <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Cari</button>
        </div>
    </div>
  </div>
</form>


<?php if($suratmasuk->count() > 0): ?>
  <div>
    <a href="/surat-masuk/create" class="btn btn-primary mb-3">
      + Tambah Surat Masuk
    </a>
  </div>

  <table class="table table-striped table-hover">
    <thead>
      <tr>
        <th scope="col">No Urut</th>
        <th scope="col">Perihal</th>
        <th scope="col">Kode</th>
        <th scope="col">No Surat</th>
        <th scope="col">Tanggal</th>
        <th scope="col">Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $suratmasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th><?php echo e($surat->no_urut); ?></th>
        <th><?php echo e($surat->perihal); ?></th>
        <td><?php echo e($surat->kode); ?></td>
        <td><?php echo e($surat->no_surat); ?></td>
        <td><?php echo e($surat->tanggal_surat); ?></td>
        <td> 
          <a href="/surat-masuk/<?php echo e($surat->id); ?>" class="btn btn-sm btn-primary">Detail</a> 
          <a href="/surat-masuk/<?php echo e($surat->id); ?>/edit" class="btn btn-sm btn-warning">Edit</a>  
          <form action="/surat-masuk/<?php echo e($surat->id); ?>" method="POST" class="d-inline">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <button class="btn btn-sm btn-danger" type="submit" onclick="return confirm('Kamu yakin?')">
              Hapus
            </button>
          </form> 
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php else: ?>
    <div class="text-center">
      <img src="/img/surat kosong.png" alt="" width="30%">
      <h2><Strong>Waduh!</Strong></h2>
      <p class="lead">Surat yang kamu cari gaada nih.. <br>Coba diperhatikan lagi kata kuncinya ya! <br>Atau membuat surat baru</p>
      <div>
        <a href="/surat-masuk/create" class="btn btn-primary mb-3">
          + Tambah Surat Masuk
        </a>
      </div>
    </div>
<?php endif; ?>


  <div class="d-flex justify-content-center">
    <?php echo e($suratmasuk->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NGODING ANJAY\Laravel\blog-post\resources\views/suratmasuk/index.blade.php ENDPATH**/ ?>