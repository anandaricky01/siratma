<footer class="pt-5">
    <div class="text-light bg-primary py-2 text-center">
        <p>Made with ❤️ - Cabang Dinas Kehutanan Wilayah Malang 2022</p>
    </div>
</footer>
</body>
</html><?php /**PATH E:\NGODING ANJAY\Laravel\blog-post\resources\views/layout/components/footer.blade.php ENDPATH**/ ?>