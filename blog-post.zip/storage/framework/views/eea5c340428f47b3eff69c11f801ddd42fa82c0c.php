

<?php $__env->startSection('container'); ?>

<div class="mb-2">
  <a href="/surat-masuk" class="btn btn-danger btn-sm">Kembali</a>
  <div class="row">
    <div class="col-4 text-end">
      <img src="/img/Surat.png" alt="" style="width: 70%; align:right;">
    </div>
    <div class="col text-start">
      <h1 class="align-middle"><strong>Detail Surat Masuk</strong></h1>
      <p class="lead">Tolong perhatikan baik - baik setiap informasi pada surat dan pastikan surat sudah memiliki data yang benar</p>
      <a href="/surat-masuk/<?php echo e($suratmasuk->id); ?>/pdf" class="btn btn-primary">Print Surat</a>
      <a href="/surat-masuk/<?php echo e($suratmasuk->id); ?>/edit" class="btn btn-warning">Edit Surat</a>
      <form action="/surat-masuk/<?php echo e($suratmasuk->id); ?>" method="POST" class="d-inline">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
        <button class="btn btn-danger" type="submit" onclick="return confirm('Kamu yakin?')">
          Hapus
        </button>
      </form> 
    </div>
  </div>
</div>

<table class="table table-bordered table-striped table-hover">
    <thead>
      <tr>
        <th scope="col" colspan="4">Detail Surat Masuk</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">Perihal</th>
        <td scope="col" colspan="3"><?php echo e($suratmasuk->perihal); ?></td>
      </tr>
      <tr>
        <th scope="row">No Urut</th>
        <td><?php echo e($suratmasuk->no_urut); ?></td>
        <th scope="row">No Surat</th>
        <td><?php echo e($suratmasuk->no_surat); ?></td>
      </tr>
      <tr>
        <th scope="row">Kode</th>
        <td><?php echo e($suratmasuk->kode); ?></td>
        <th scope="row">Tanggal Surat</th>
        <td><?php echo e($suratmasuk->tanggal_surat); ?></td>
      </tr>
      <tr>
        <th scope="row">Pengolah</th>
        <td><?php echo e($suratmasuk->pengolah); ?></td>
        <th scope="row">Tanggal Diteruskan</th>
        <td><?php echo e($suratmasuk->tanggal_diteruskan); ?></td>
      </tr>
      <tr>
        <th scope="row">Jumlah Lampiran</th>
        <td><?php echo e($suratmasuk->lampiran); ?> Lembar</td>
        <th scope="row">Tanda Diterima</th>
        <td><?php echo e($suratmasuk->tanda_diterima); ?></td>
      </tr>
      <tr>
        <th scope="row">Dari</th>
        <td scope="col" colspan="3"><?php echo e($suratmasuk->dari_kepada); ?></td>
      </tr>
      <tr>
        <th scope="row">Isi Ringkas</th>
        <td scope="col" colspan="3"><?php echo e($suratmasuk->isi_ringkas); ?></td>
      </tr>
      <tr>
        <th scope="row">Catatan</th>
        <td scope="col" colspan="3"><?php echo e($suratmasuk->catatan); ?></td>
      </tr>
    </tbody>
  </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NGODING ANJAY\Laravel\blog-post\resources\views/suratmasuk/show.blade.php ENDPATH**/ ?>