<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
      <a class="navbar-brand" href="/home"> <strong>SiRatma</strong></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('home') ? 'active' : ''); ?>" href="/home">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('surat-masuk*') ? 'active' : ''); ?>" href="/surat-masuk">Surat Masuk</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('surat-keluar*') ? 'active' : ''); ?>" href="/surat-keluar">Surat Keluar</a>
          </li>
        </ul>
        <ul class="navbar-nav ms-auto">
          
          <li class="nav-item">
            <form action="/logout" method="post">  
              <?php echo csrf_field(); ?>
              <button type="submit" class="nav-link px-3 border-0 bg-primary"> Log out <span data-feather="log-out"></span></button>
            </form>
          </li>
          
        </ul>
      </div>
    </div>
  </nav>
<?php /**PATH E:\NGODING ANJAY\Laravel\blog-post\resources\views/layout/components/navbar.blade.php ENDPATH**/ ?>