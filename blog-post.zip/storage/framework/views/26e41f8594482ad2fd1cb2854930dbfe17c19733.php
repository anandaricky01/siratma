<?php echo $__env->make('layout.components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layout.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container my-3">
    <?php echo $__env->yieldContent('container'); ?>
</div>

<?php echo $__env->make('layout.components.javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\NGODING ANJAY\Laravel\blog-post\resources\views/layout/layout.blade.php ENDPATH**/ ?>